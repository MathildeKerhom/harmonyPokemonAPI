INSERT INTO `pokemon_arenes`(`id`, `nom`, `badge_id`, `position_id`) VALUES (1,'Arène d\'Argenta',1,1);
INSERT INTO `pokemon_arenes`(`id`, `nom`, `badge_id`, `position_id`) VALUES (2,'Arène d\'Azuria',2,2);
INSERT INTO `pokemon_arenes`(`id`, `nom`, `badge_id`, `position_id`) VALUES (3,'Arène de Carmin Sur Mer',3,3);
INSERT INTO `pokemon_arenes`(`id`, `nom`, `badge_id`, `position_id`) VALUES (4,'Arène de Céladopole',4,4);
INSERT INTO `pokemon_arenes`(`id`, `nom`, `badge_id`, `position_id`) VALUES (5,'Arène de Parmanie',5,5);
INSERT INTO `pokemon_arenes`(`id`, `nom`, `badge_id`, `position_id`) VALUES (6,'Arène de Safrania',6,6);
INSERT INTO `pokemon_arenes`(`id`, `nom`, `badge_id`, `position_id`) VALUES (7,'Arène de Cramois\'Île',7,7);
INSERT INTO `pokemon_arenes`(`id`, `nom`, `badge_id`, `position_id`) VALUES (8,'Arène de Jadielle',8,8);