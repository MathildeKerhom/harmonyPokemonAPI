#------------------------------------------------------------
#        Script MySQL.
#------------------------------------------------------------


#------------------------------------------------------------
# Table: attaques
#------------------------------------------------------------

CREATE TABLE attaques(
        id_attaques Smallint NOT NULL ,
        nom         Varchar (12) ,
        puissance   Smallint ,
        precis      TinyINT ,
        id_types    TinyINT NOT NULL ,
        PRIMARY KEY (id_attaques )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: badges
#------------------------------------------------------------

CREATE TABLE badges(
        id_badges   TinyINT NOT NULL ,
        nom         Varchar (7) NOT NULL ,
        id_dresseur Int NOT NULL ,
        id_zones    TinyINT NOT NULL ,
        id_arene    TinyINT ,
        PRIMARY KEY (id_badges )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: dresseurs
#------------------------------------------------------------

CREATE TABLE dresseurs(
        id_dresseur  Int NOT NULL ,
        nom          Varchar (15) NOT NULL ,
        id_nonjoueur Int ,
        PRIMARY KEY (id_dresseur )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: pokemons
#------------------------------------------------------------

CREATE TABLE pokemons(
        id_pokemons      Int NOT NULL ,
        surnom           Varchar (30) NOT NULL ,
        niveau           TinyINT ,
        capture          Date NOT NULL ,
        id_dresseur      Int NOT NULL ,
        id_attaques      Smallint NOT NULL ,
        id_attaques_1    Smallint NOT NULL ,
        id_attaques_2    Smallint NOT NULL ,
        id_attaques_3    Smallint NOT NULL ,
        id_type_pokemons Smallint NOT NULL ,
        PRIMARY KEY (id_pokemons )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: positions
#------------------------------------------------------------

CREATE TABLE positions(
        id_positions Int NOT NULL ,
        x            Int ,
        y            Int ,
        id_zones     TinyINT NOT NULL ,
        id_arene     TinyINT ,
        PRIMARY KEY (id_positions )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: typedepokemons
#------------------------------------------------------------

CREATE TABLE typedepokemons(
        id_type_pokemons Smallint NOT NULL ,
        nom              Varchar (10) NOT NULL ,
        attaque          Smallint ,
        attaque_spe      Smallint ,
        defence          Smallint ,
        defence_spe      Smallint ,
        vitesse          Smallint ,
        pv               Smallint ,
        id_pokedex       Smallint NOT NULL ,
        PRIMARY KEY (id_type_pokemons )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: types
#------------------------------------------------------------

CREATE TABLE types(
        id_types TinyINT NOT NULL ,
        nom      Varchar (7) NOT NULL ,
        PRIMARY KEY (id_types )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: zones
#------------------------------------------------------------

CREATE TABLE zones(
        id_zones TinyINT NOT NULL ,
        nom      Varchar (25) NOT NULL ,
        PRIMARY KEY (id_zones )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: npc
#------------------------------------------------------------

CREATE TABLE npc(
        id_nonjoueur int (11) Auto_increment  NOT NULL ,
        nom          Varchar (15) NOT NULL ,
        profession   Varchar (25) ,
        texte        Varchar (140) ,
        id_dresseur  Int ,
        PRIMARY KEY (id_nonjoueur )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: objets
#------------------------------------------------------------

CREATE TABLE objets(
        id_objet     int (11) Auto_increment  NOT NULL ,
        nom          Varchar (20) NOT NULL ,
        quantite     TinyINT NOT NULL ,
        id_nonjoueur Int ,
        id_typeObjet TinyINT NOT NULL ,
        PRIMARY KEY (id_objet )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: typeObjet
#------------------------------------------------------------

CREATE TABLE typeObjet(
        id_typeObjet TinyINT NOT NULL ,
        nom          Varchar (10) NOT NULL ,
        PRIMARY KEY (id_typeObjet )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: pokedex
#------------------------------------------------------------

CREATE TABLE pokedex(
        id_pokedex Smallint NOT NULL ,
        PRIMARY KEY (id_pokedex )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: arenes
#------------------------------------------------------------

CREATE TABLE arenes(
        id_arene     TinyINT NOT NULL ,
        nom          Varchar (25) NOT NULL ,
        id_badges    TinyINT NOT NULL ,
        id_positions Int NOT NULL ,
        PRIMARY KEY (id_arene )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: evolueen
#------------------------------------------------------------

CREATE TABLE evolueen(
        id_type_pokemons                Smallint NOT NULL ,
        id_type_pokemons_typedepokemons Smallint NOT NULL ,
        PRIMARY KEY (id_type_pokemons ,id_type_pokemons_typedepokemons )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: faiblecontre
#------------------------------------------------------------

CREATE TABLE faiblecontre(
        modificateur Decimal (4) ,
        id_types     TinyINT NOT NULL ,
        id_types_1   TinyINT NOT NULL ,
        PRIMARY KEY (id_types ,id_types_1 )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: fortcontre
#------------------------------------------------------------

CREATE TABLE fortcontre(
        modificateur Decimal (4) ,
        id_types     TinyINT NOT NULL ,
        id_types_1   TinyINT NOT NULL ,
        PRIMARY KEY (id_types ,id_types_1 )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: gagne
#------------------------------------------------------------

CREATE TABLE gagne(
        obtention   Date ,
        id_dresseur Int NOT NULL ,
        id_badges   TinyINT NOT NULL ,
        PRIMARY KEY (id_dresseur ,id_badges )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: possedelestypes
#------------------------------------------------------------

CREATE TABLE possedelestypes(
        id_type_pokemons Smallint NOT NULL ,
        id_types         TinyINT NOT NULL ,
        PRIMARY KEY (id_type_pokemons ,id_types )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: viedans
#------------------------------------------------------------

CREATE TABLE viedans(
        id_zones         TinyINT NOT NULL ,
        id_type_pokemons Smallint NOT NULL ,
        PRIMARY KEY (id_zones ,id_type_pokemons )
)ENGINE=InnoDB;

ALTER TABLE attaques ADD CONSTRAINT FK_attaques_id_types FOREIGN KEY (id_types) REFERENCES types(id_types);
ALTER TABLE badges ADD CONSTRAINT FK_badges_id_dresseur FOREIGN KEY (id_dresseur) REFERENCES dresseurs(id_dresseur);
ALTER TABLE badges ADD CONSTRAINT FK_badges_id_zones FOREIGN KEY (id_zones) REFERENCES zones(id_zones);
ALTER TABLE badges ADD CONSTRAINT FK_badges_id_arene FOREIGN KEY (id_arene) REFERENCES arenes(id_arene);
ALTER TABLE dresseurs ADD CONSTRAINT FK_dresseurs_id_nonjoueur FOREIGN KEY (id_nonjoueur) REFERENCES npc(id_nonjoueur);
ALTER TABLE pokemons ADD CONSTRAINT FK_pokemons_id_dresseur FOREIGN KEY (id_dresseur) REFERENCES dresseurs(id_dresseur);
ALTER TABLE pokemons ADD CONSTRAINT FK_pokemons_id_attaques FOREIGN KEY (id_attaques) REFERENCES attaques(id_attaques);
ALTER TABLE pokemons ADD CONSTRAINT FK_pokemons_id_attaques_1 FOREIGN KEY (id_attaques_1) REFERENCES attaques(id_attaques);
ALTER TABLE pokemons ADD CONSTRAINT FK_pokemons_id_attaques_2 FOREIGN KEY (id_attaques_2) REFERENCES attaques(id_attaques);
ALTER TABLE pokemons ADD CONSTRAINT FK_pokemons_id_attaques_3 FOREIGN KEY (id_attaques_3) REFERENCES attaques(id_attaques);
ALTER TABLE pokemons ADD CONSTRAINT FK_pokemons_id_type_pokemons FOREIGN KEY (id_type_pokemons) REFERENCES typedepokemons(id_type_pokemons);
ALTER TABLE positions ADD CONSTRAINT FK_positions_id_zones FOREIGN KEY (id_zones) REFERENCES zones(id_zones);
ALTER TABLE positions ADD CONSTRAINT FK_positions_id_arene FOREIGN KEY (id_arene) REFERENCES arenes(id_arene);
ALTER TABLE typedepokemons ADD CONSTRAINT FK_typedepokemons_id_pokedex FOREIGN KEY (id_pokedex) REFERENCES pokedex(id_pokedex);
ALTER TABLE npc ADD CONSTRAINT FK_npc_id_dresseur FOREIGN KEY (id_dresseur) REFERENCES dresseurs(id_dresseur);
ALTER TABLE objets ADD CONSTRAINT FK_objets_id_nonjoueur FOREIGN KEY (id_nonjoueur) REFERENCES npc(id_nonjoueur);
ALTER TABLE objets ADD CONSTRAINT FK_objets_id_typeObjet FOREIGN KEY (id_typeObjet) REFERENCES typeObjet(id_typeObjet);
ALTER TABLE arenes ADD CONSTRAINT FK_arenes_id_badges FOREIGN KEY (id_badges) REFERENCES badges(id_badges);
ALTER TABLE arenes ADD CONSTRAINT FK_arenes_id_positions FOREIGN KEY (id_positions) REFERENCES positions(id_positions);
ALTER TABLE evolueen ADD CONSTRAINT FK_evolueen_id_type_pokemons FOREIGN KEY (id_type_pokemons) REFERENCES typedepokemons(id_type_pokemons);
ALTER TABLE evolueen ADD CONSTRAINT FK_evolueen_id_type_pokemons_typedepokemons FOREIGN KEY (id_type_pokemons_typedepokemons) REFERENCES typedepokemons(id_type_pokemons);
ALTER TABLE faiblecontre ADD CONSTRAINT FK_faiblecontre_id_types FOREIGN KEY (id_types) REFERENCES types(id_types);
ALTER TABLE faiblecontre ADD CONSTRAINT FK_faiblecontre_id_types_1 FOREIGN KEY (id_types_1) REFERENCES types(id_types);
ALTER TABLE fortcontre ADD CONSTRAINT FK_fortcontre_id_types FOREIGN KEY (id_types) REFERENCES types(id_types);
ALTER TABLE fortcontre ADD CONSTRAINT FK_fortcontre_id_types_1 FOREIGN KEY (id_types_1) REFERENCES types(id_types);
ALTER TABLE gagne ADD CONSTRAINT FK_gagne_id_dresseur FOREIGN KEY (id_dresseur) REFERENCES dresseurs(id_dresseur);
ALTER TABLE gagne ADD CONSTRAINT FK_gagne_id_badges FOREIGN KEY (id_badges) REFERENCES badges(id_badges);
ALTER TABLE possedelestypes ADD CONSTRAINT FK_possedelestypes_id_type_pokemons FOREIGN KEY (id_type_pokemons) REFERENCES typedepokemons(id_type_pokemons);
ALTER TABLE possedelestypes ADD CONSTRAINT FK_possedelestypes_id_types FOREIGN KEY (id_types) REFERENCES types(id_types);
ALTER TABLE viedans ADD CONSTRAINT FK_viedans_id_zones FOREIGN KEY (id_zones) REFERENCES zones(id_zones);
ALTER TABLE viedans ADD CONSTRAINT FK_viedans_id_type_pokemons FOREIGN KEY (id_type_pokemons) REFERENCES typedepokemons(id_type_pokemons);
