INSERT INTO `pokemon_npc`(`id`, `position_id`, `nom`, `profession`, `texte`) VALUES (1, null, 'Pierre','Champion','J\'aime les pokémons roche !');
INSERT INTO `pokemon_npc`(`id`, `position_id`, `nom`, `profession`, `texte`) VALUES (2, null, 'Ondine','Champion','J\'aime les pokémons eau !');
INSERT INTO `pokemon_npc`(`id`, `position_id`, `nom`, `profession`, `texte`) VALUES (3, null, 'Major Bob','Champion','J\'aime les pokémons électrique !');
INSERT INTO `pokemon_npc`(`id`, `position_id`, `nom`, `profession`, `texte`) VALUES (4, null, 'Érika','Champion','J\'aime les pokémons plante !');
INSERT INTO `pokemon_npc`(`id`, `position_id`, `nom`, `profession`, `texte`) VALUES (5, null, 'Koga','Champion','J\'aime les pokémons poison !');
INSERT INTO `pokemon_npc`(`id`, `position_id`, `nom`, `profession`, `texte`) VALUES (6, null, 'Morgane','Champion','J\'aime les pokémons psy !');
INSERT INTO `pokemon_npc`(`id`, `position_id`, `nom`, `profession`, `texte`) VALUES (7, null, 'Auguste','Champion','J\'aime les pokémons auguste !');
INSERT INTO `pokemon_npc`(`id`, `position_id`, `nom`, `profession`, `texte`) VALUES (8, null, 'Giovanni','Champion','J\'aime les pokémons sol !');

INSERT INTO `pokemon_dresseurs`(`id`, `nom`, `npc_id`) VALUES (1, 'Pierre', 1);
INSERT INTO `pokemon_dresseurs`(`id`, `nom`, `npc_id`) VALUES (2, 'Ondine', 2);
INSERT INTO `pokemon_dresseurs`(`id`, `nom`, `npc_id`) VALUES (3, 'Major Bob', 3);
INSERT INTO `pokemon_dresseurs`(`id`, `nom`, `npc_id`) VALUES (4, 'Érika', 4);
INSERT INTO `pokemon_dresseurs`(`id`, `nom`, `npc_id`) VALUES (5, 'Koga', 5);
INSERT INTO `pokemon_dresseurs`(`id`, `nom`, `npc_id`) VALUES (6, 'Morgane', 6);
INSERT INTO `pokemon_dresseurs`(`id`, `nom`, `npc_id`) VALUES (7, 'Auguste', 7);
INSERT INTO `pokemon_dresseurs`(`id`, `nom`, `npc_id`) VALUES (8, 'Giovanni', 8);