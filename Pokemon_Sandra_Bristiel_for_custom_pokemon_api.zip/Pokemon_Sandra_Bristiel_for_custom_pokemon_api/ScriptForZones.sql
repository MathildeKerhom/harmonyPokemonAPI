INSERT INTO `pokemon_zones`(`id`, `nom`) VALUES (1,'Celadopole');
INSERT INTO `pokemon_zones`(`id`, `nom`) VALUES (2,'Lavanville');
INSERT INTO `pokemon_zones`(`id`, `nom`) VALUES (3,'Parmanie');
INSERT INTO `pokemon_zones`(`id`, `nom`) VALUES (4,'Safrania');
INSERT INTO `pokemon_zones`(`id`, `nom`) VALUES (5,'Argenta');
INSERT INTO `pokemon_zones`(`id`, `nom`) VALUES (6,'Azuria');
INSERT INTO `pokemon_zones`(`id`, `nom`) VALUES (7,'Carmin Sur Mer');
INSERT INTO `pokemon_zones`(`id`, `nom`) VALUES (8,'Cramois\'Île');
INSERT INTO `pokemon_zones`(`id`, `nom`) VALUES (9,'Jadielle');