INSERT INTO `pokemon_badges`(`id`, `nom`) VALUES (1,'Roche');
INSERT INTO `pokemon_badges`(`id`, `nom`) VALUES (2,'Cascade');
INSERT INTO `pokemon_badges`(`id`, `nom`) VALUES (3,'Foudre');
INSERT INTO `pokemon_badges`(`id`, `nom`) VALUES (4,'Prisme');
INSERT INTO `pokemon_badges`(`id`, `nom`) VALUES (5,'Âme');
INSERT INTO `pokemon_badges`(`id`, `nom`) VALUES (6,'Marais');
INSERT INTO `pokemon_badges`(`id`, `nom`) VALUES (7,'Volcan');
INSERT INTO `pokemon_badges`(`id`, `nom`) VALUES (8,'Terre');