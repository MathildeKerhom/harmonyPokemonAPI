INSERT INTO `pokemon_typeobjet`(`id`, `nom`) VALUES (1,'Standards');
INSERT INTO `pokemon_typeobjet`(`id`, `nom`) VALUES (2,'Médicaments');
INSERT INTO `pokemon_typeobjet`(`id`, `nom`) VALUES (3,'Balls');
INSERT INTO `pokemon_typeobjet`(`id`, `nom`) VALUES (4,'CT/CS');
INSERT INTO `pokemon_typeobjet`(`id`, `nom`) VALUES (5,'Combat');
INSERT INTO `pokemon_typeobjet`(`id`, `nom`) VALUES (6,'Rares');